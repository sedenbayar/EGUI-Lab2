﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Planner.Models
{
    public class RootObjectModel
    {
        public List<Activity> Activities { get; set; }
        public List<string> Groups { get; set; }
        public List<string> Lectures { get; set; }
        public List<string> Rooms { get; set; }
        public List<string> Teachers { get; set; }

        public Activity FindActivity(string room, string day, int slot)
        {
            return Activities.Where(x => x.Room == room && x.Day == day && x.Slot == slot).FirstOrDefault();
        }
    }

    public class Activity
    {
        public string Day { get; set; }
        public string Group { get; set; }
        public string Lecture { get; set; }
        public string Room { get; set; }
        public int Slot { get; set; }
        public string Teacher { get; set; }
    }
}
