﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Planner.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;

namespace Planner.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        private static RootObjectModel ReadJSON()
        {
			using var reader = new StreamReader("data.json");
			var json = reader.ReadToEnd();
			var allVariables = JsonConvert.DeserializeObject<RootObjectModel>(json);
			return allVariables;
		}

        private static void WriteJSON(RootObjectModel obj)
        {
			using var writer = new StreamWriter("data.json", append: false);
			var json = JsonConvert.SerializeObject(obj, Formatting.Indented);
			writer.WriteLine(json);
		}

        public IActionResult Index(string room)
        {
            ViewData["Room"] = room;
            return View(ReadJSON());
        }

        public IActionResult GetData(string room)
        {
            var obj = ReadJSON();
            var filter = obj.Activities.Where(x => x.Room == room);
            return Json(new { activities = filter, count = filter.Count() });
        }

        public IActionResult Groups()
        {
            return View(ReadJSON());
        }

        public IActionResult Lectures()
        {
            return View(ReadJSON());
        }

        public IActionResult Rooms()
        {
            return View(ReadJSON());
        }

        public IActionResult Teachers()
        {
            return View(ReadJSON());
        }

        public IActionResult ShowGroup(string name)
        {
            ViewData["Group"] = name;
            return View();
        }

        public IActionResult ShowLecture(string name)
        {
            ViewData["Lecture"] = name;
            return View();
        }

        public IActionResult ShowRoom(string name)
        {
            ViewData["Room"] = name;
            return View();
        }

        public IActionResult ShowTeacher(string name)
        {
            ViewData["Teacher"] = name;
            return View();
        }
        public IActionResult ShowCell(string room, string day, int slot)
        {
            ViewData["Room"] = room;
            ViewData["Day"] = day;
            ViewData["Slot"] = slot;
            return View(ReadJSON());
        }

        public IActionResult RemoveGroup(string name)
        {
            var obj = ReadJSON();
            var result = obj.Groups.Remove(name);
            var removed = result ? obj.Activities.RemoveAll(x => x.Group == name) : 0;
            WriteJSON(obj);
            return Json(new { result, removed });
        }

        public IActionResult RemoveLecture(string name)
        {
            var obj = ReadJSON();
            var result = obj.Lectures.Remove(name);
            var removed = result ? obj.Activities.RemoveAll(x => x.Lecture == name) : 0;
            WriteJSON(obj);
            return Json(new { result, removed });
        }

        public IActionResult RemoveRoom(string name)
        {
            var obj = ReadJSON();
            var result = obj.Rooms.Remove(name);
            var removed = result ? obj.Activities.RemoveAll(x => x.Room == name) : 0;
            WriteJSON(obj);
            return Json(new { result, removed });
        }

        public IActionResult RemoveTeacher(string name)
        {
            var obj = ReadJSON();
            var result = obj.Teachers.Remove(name);
            var removed = result ? obj.Activities.RemoveAll(x => x.Teacher == name) : 0;
            WriteJSON(obj);
            return Json(new { result, removed });
        }

        public IActionResult RemoveCell(string room, string day, int slot)
        {
            var obj = ReadJSON();
            var result = false;
            var found = obj.FindActivity(room, day, slot);
            if (found != null)
            {
                result = obj.Activities.Remove(found);
            }
            WriteJSON(obj);
            return Json(new { result });
        }

        public IActionResult EditGroup(string curr, string prev)
        {
            var obj = ReadJSON(); 
            if (!string.IsNullOrEmpty(prev))
            {
                obj.Groups.Remove(prev);

                foreach (var activity in obj.Activities)
                {
                    if (activity.Group == prev)
                        activity.Group = curr;
                }
            }
            obj.Groups.Add(curr);
            WriteJSON(obj);
            return Json(new { curr, prev });
        }

        public IActionResult EditLecture(string curr, string prev)
        {
            var obj = ReadJSON();
            if (!string.IsNullOrEmpty(prev))
            {
                obj.Lectures.Remove(prev);

                foreach (var activity in obj.Activities)
                {
                    if (activity.Lecture == prev)
                        activity.Lecture = curr;
                }
            }
            obj.Lectures.Add(curr);
            WriteJSON(obj);
            return Json(new { curr, prev });
        }

        public IActionResult EditRoom(string curr, string prev)
        {
            var obj = ReadJSON();
            if (!string.IsNullOrEmpty(prev))
            {
                obj.Rooms.Remove(prev);

                foreach (var activity in obj.Activities)
                {
                    if (activity.Room == prev)
                        activity.Room = curr;
                }
            }
            obj.Rooms.Add(curr);
            WriteJSON(obj);
            return Json(new { curr, prev });
        }

        public IActionResult EditTeacher(string curr, string prev)
        {
            var obj = ReadJSON();
            if (!string.IsNullOrEmpty(prev))
            {
                obj.Teachers.Remove(prev);

                foreach (var activity in obj.Activities)
                {
                    if (activity.Teacher == prev)
                        activity.Teacher = curr;
                }
            }
            obj.Teachers.Add(curr);
            WriteJSON(obj);
            return Json(new { curr, prev });
        }

        public IActionResult EditCell(string room, string day, int slot, string teacher, string lecture, string group)
        {
            var obj = ReadJSON();
            var act = obj.FindActivity(room, day, slot);
            if (act != null)
            {
                act.Group = group;
                act.Lecture = lecture;
                act.Teacher = teacher;
            }
            else
            {
                obj.Activities.Add(new Models.Activity()
                {
                    Day = day,
                    Room = room,
                    Slot = slot,
                    Group = group,
                    Lecture = lecture,
                    Teacher = teacher
                });
            }
            WriteJSON(obj);
            return Json(new { room, day, slot });
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = System.Diagnostics.Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
